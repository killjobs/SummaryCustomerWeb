import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { SummaryCustomerService } from '../../services/summary-customer.service';

@Component({
  selector: 'app-summary-customer-detail',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './summary-customer-detail.component.html',
  styleUrl: './summary-customer-detail.component.scss'
})

export class SummaryCustomerDetailComponent {
  customerDetail: any;
  complementText: string = "";
  @Input() customer: any; // Recibimos la información del cliente
    
  constructor(private summaryCustomerService : SummaryCustomerService) {
    this.Close();
  }

  GetSummaryDetail(position: number) {
    this.complementText = position == 1 ? "Nombre" : "Teléfono";
    let searchText:string = position == 1 ? this.customer.fullName : this.customer.phoneNumber;
    this.summaryCustomerService.GetSummaryCustomerDetail(searchText).subscribe(data => {
      this.customerDetail = data.result;
    });
  }

  Close(){
    this.complementText = "";
    this.customerDetail = null;
  }
}
