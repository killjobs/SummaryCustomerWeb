import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { SummaryCustomerService } from '../../services/summary-customer.service';
import { mensajeError, mensajeExitoso } from '../../Common/HandleMessages';
import { Router } from '@angular/router';
import { SummaryCustomer } from '../../models/summary-customer';

@Component({
  selector: 'app-manage-summary-customer',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './manage-summary-customer.component.html',
  styleUrl: './manage-summary-customer.component.scss'
})
export class ManageSummaryCustomerComponent implements OnInit{
  customerForm: FormGroup;
  @Input() isEditing : boolean = false;
  @Input() customer: any; // Recibimos la información del cliente
  @Output() closeModal = new EventEmitter<void>();  // Evento para cerrar el modal
  
  maxDate = new Date().toISOString().split('T')[0];

  selectedCustomer: SummaryCustomer = {
    id: 0,
    userId: 0,
    orderNumber: 0,
    fullName: '',
    phoneNumber: '',
    purchaseSummary: '',
    cost: 0
  };

  constructor(private fb: FormBuilder, private summaryCustomerService: SummaryCustomerService, private router: Router) {
    this.customerForm = this.fb.group({
      orderNumber: ['', [Validators.required, Validators.pattern(/^\d+$/)]], // Solo números
      createdDate: ['', [Validators.required]], // Fecha obligatoria
      fullName: ['', [Validators.required, Validators.pattern(/^(?! )[A-Za-z ]*(?<! )$/)]], // Solo letras y espacios (sin espacios al inicio o al final)
      phoneNumber: ['', [Validators.required, Validators.pattern(/^\d+$/)]], // Solo números
      purchaseSummary: ['', Validators.required],
      cost: ['', [Validators.required, Validators.min(1), Validators.pattern(/^\d+$/)]], // Solo números y mayor a 0
    });
  }

  ngOnInit(): void {}

  isInvalid(field: string): boolean {
    return this.customerForm.controls[field].invalid && this.customerForm.controls[field].touched;
  }

  loadSummaryCustomer(customer?: any): void {
    if (customer) {
      customer.createdDate = customer.createdDate ? customer.createdDate.split('T')[0] : '';
      this.selectedCustomer = customer;
      this.customerForm.patchValue(customer);
    } else {
      this.limpiarFormulario();
    }
  }

  saveUpdateSummaryCustomer(): void {
    if (this.customerForm.valid) {

      this.selectedCustomer.orderNumber = Number(this.customerForm.value.orderNumber);
      this.selectedCustomer.fullName = this.customerForm.value.fullName;
      this.selectedCustomer.createdDate = this.customerForm.value.createdDate;
      this.selectedCustomer.phoneNumber = this.customerForm.value.phoneNumber;
      this.selectedCustomer.purchaseSummary = this.customerForm.value.purchaseSummary;
      this.selectedCustomer.cost = this.customerForm.value.cost;

      this.summaryCustomerService.SaveUpdateSummaryCustomer(this.selectedCustomer).subscribe({
        next:(result:any)=>{
          mensajeExitoso("Paciente Creado / Actualizado correctamente");
          this.closeModal.emit();
        },
        error:()=>{
          mensajeError('Se presento un error al realizar la actualización / guardado del paciente.');
        },
        complete:()=>{
          this.limpiarFormulario();
          this.router.navigate([`home`]);
        }
      });
    }
  }
  
  limpiarFormulario() {
    this.isEditing = false;
    this.customerForm.reset();
    this.customer = null;
    this.selectedCustomer = {
      id: 0,
      userId: 0,
      orderNumber: 0,
      fullName: '',
      phoneNumber: '',
      purchaseSummary: '',
      cost: 0
    };
  }

}
