import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageSummaryCustomerComponent } from './manage-summary-customer.component';

describe('ManageSummaryCustomerComponent', () => {
  let component: ManageSummaryCustomerComponent;
  let fixture: ComponentFixture<ManageSummaryCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManageSummaryCustomerComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ManageSummaryCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
