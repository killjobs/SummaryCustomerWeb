import Swal from "sweetalert2";

export function mensajeError(text:string){
    Swal.fire({
        title: 'Error',
        text: text,
        icon: 'error',
        confirmButtonText:'Continuar'
      });
}

export function mensajeExitoso(text : string){
  Swal.fire({
      position: "top-end",
      icon: "success",
      title: text,
      showConfirmButton: false,
      timer: 1500
    });
}

export function mensajeInformativo(text : string){
  Swal.fire({
      title: 'Información',
      text: text,
      icon: 'info',
      confirmButtonText:'Continuar'
    });
}
