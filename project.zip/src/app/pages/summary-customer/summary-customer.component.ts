import { Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SummaryCustomerService } from '../../services/summary-customer.service';
import { SummaryCustomer } from '../../models/summary-customer';
import { SummaryCustomerDetailComponent } from '../../components/summary-customer-detail/summary-customer-detail.component';
import { ManageSummaryCustomerComponent } from '../../components/manage-summary-customer/manage-summary-customer.component';
import { mensajeError } from '../../Common/HandleMessages';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-summary-customer',
  standalone: true,
  imports: [CommonModule, FormsModule, SummaryCustomerDetailComponent, ManageSummaryCustomerComponent],
  templateUrl: './summary-customer.component.html',
  styleUrl: './summary-customer.component.scss'
})
export class SummaryCustomerComponent implements OnInit{
  @ViewChild (SummaryCustomerDetailComponent) modalReview: any;
  @ViewChild (ManageSummaryCustomerComponent) modalManage: any;
  @ViewChild('ModalReview', { static: false }) modalReviewActions!: ElementRef;
  
  constructor(private authService: AuthService, private summaryCustomerService : SummaryCustomerService){}

  Math = Math;
  summaryCustomers: SummaryCustomer[] = [];
  searchText: string = '';
  selectedSummary: any = null;

  // Variables para paginación
  pageSizeOptions: number[] = [5, 10, 15, 20, 25, 100];
  page: number = 1;
  pageSize: number = 10;
  totalResult: number = 0;

  ngOnInit(): void {
    this.GetSummaryCustomer();
  }

  onSearchChange(): void {
    this.page = 1; // Reiniciar a la primera página al buscar
    this.GetSummaryCustomer();
  }
  
  onPageSizeChange(): void {
    this.page = 1; // Reiniciar a la primera página al cambiar el tamaño
    this.GetSummaryCustomer();
  }

  changePage(newPage: number): void {
    this.page = newPage;
    this.GetSummaryCustomer();
  }

  get filteredUsers() {
    return this.summaryCustomers.filter(value =>
      value.fullName.toLowerCase().includes(this.searchText.toLowerCase()) ||
      value.phoneNumber.includes(this.searchText) ||
      value.purchaseSummary.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }

  GetSummaryCustomer(): void {
    this.summaryCustomerService.GetSummaryCustomer(this.searchText, this.page, this.pageSize).subscribe(data => {
      if (data.success) {
        this.summaryCustomers = data.result;
        this.totalResult = data.totalResult;
      } else {
        mensajeError("Error interno, contactar a soporte técnico");
      }
    });
  }

  viewDetail(summary: any) {
    this.modalReview.customer = summary;
  }


  viewCreateSummaryCustomer(){
      this.modalManage.limpiarFormulario();
      this.modalManage.isEditing = false;
      var userIdSession = Number(sessionStorage.getItem('userId') != null ? sessionStorage.getItem('userId') : 0);
      this.modalManage.customer = {
        id: 0,
        userId: userIdSession,
        orderNumber: 0,
        fullName: '',
        phoneNumber: '',
        purchaseSummary: '',
        cost: 0
      };
    this.modalManage.loadSummaryCustomer(this.modalManage.customer);
  }

  viewUpdateSummaryCustomer(summary: any){
    this.modalManage.isEditing = true;
    this.modalManage.customer = summary;
    this.modalManage.loadSummaryCustomer(summary);
  }

  LogOut(): void {
    this.authService.LogOut();
  }

  closeModal(): void {
    const modalElement = document.getElementById('ModalManage');
  
    if (modalElement) {
      // Obtener la instancia del modal
      const modalInstance = bootstrap.Modal.getInstance(modalElement);
  
      // Cerrar el modal si la instancia existe
      modalInstance?.hide();
  
      // Eliminar el div de backdrop manualmente
      const backdrop = document.querySelector('.modal-backdrop');
      if (backdrop) {
        backdrop.classList.remove('show'); // Remueve la clase 'show' para ocultarlo
        backdrop.classList.add('fade'); // Agrega la clase 'fade' para que desaparezca con transición
        setTimeout(() => {
          backdrop.remove(); // Elimina el backdrop completamente después de la transición
        }, 150); // 150 ms es el tiempo de transición de Bootstrap para el backdrop
      }
    } else {
      mensajeError("Error interno, contactar a soporte técnico");
    }
  }

}
